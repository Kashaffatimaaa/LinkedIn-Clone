import express from 'express';
import authRoutes from './routes/auth.route.js';  // Ensure correct path
import { main } from './controllers/main.js';  // Ensure this path is correct

const app = express();
app.use(express.json());

app.use('/auth', authRoutes);

app.listen(5000, () => {
  console.log('Server is running on port 5000');
  main();  // Call the main function to prompt user input
});
