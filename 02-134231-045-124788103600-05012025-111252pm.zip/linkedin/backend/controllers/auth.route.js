const express = require('express');
const router = express.Router();
const { signup, login, logout, getCurrentUser } = require('./controllers/auth.controller'); // Corrected import path

router.post('/signup', signup);
router.post('/login', login);
router.post('/logout', logout);
router.get('/current-user', getCurrentUser);

module.exports = router;